﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loopgithub
{
    public partial class Form1 : Form
    {
        int pounds, kilograms;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            if (Double.TryParse(textBox1.Text, out Double pounds)) ;
            {
                for (int i = 1; i <= 5; i++)
                {


                    {

                        double kilograms = pounds * 0.45359237;


                        MessageBox.Show($"i={i},pounds={pounds},kilograms={kilograms:F2}", " answer");// display pounds in textbox 1
                    }


                }
            }
        }
    }
}

