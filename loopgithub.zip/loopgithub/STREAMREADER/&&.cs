﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

 namespace exception
{
    public partial class Form1 : Form
        
    {
       int h;
         int w;
        int t;
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0)
                MessageBox.Show("Normal weight");
            else if (listBox1.SelectedIndex == 1)
                MessageBox.Show("Over weight");
            else if (listBox1.SelectedIndex == 2)
                MessageBox.Show("Obesity level");
            else if (listBox1.SelectedIndex == 3)
                MessageBox.Show("Obesity level 2");
            else
            {
                MessageBox.Show("Obesity level 3");
            }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            h = int.Parse(textBox1.Text);
            w = int.Parse(textBox2.Text);
            t = w / (h * h);
            button1.Text = String.Format("{0:f}", t);
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
