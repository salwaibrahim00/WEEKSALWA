﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arrays
{
    public partial class Form1 : Form
    {
        string[] texts = new string[5];
        double[] nums = new double[3];
        List<int> listNums = new List<int>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            texts[0] = textBox1.Text;
            texts[1] = textBox2.Text;
            texts[2] = textBox3.Text;
            texts[3] = "stroke";
            texts[4] = "diabetes";
            string longText = "";
            for(int i=0; i<texts.Length;i++)
            {
                longText += texts[i]+""; //longtext=longtext+texts[i]
            }

            textBox4.Text = longText;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double sum = 0;
            nums[0] = double.Parse(textBox6.Text);
            nums[1] = double.Parse(textBox7.Text);
            nums[2] = double.Parse(textBox8.Text);
            for(int i=0;i < nums.Length;i++)
            {
                sum += nums[i];
                textBox5.Text = sum.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listNums.Add(int.Parse(textBox9.Text));
            listNums.Add(int.Parse(textBox10.Text));
            listNums.Add(int.Parse(textBox11.Text));
            textBox12.Text = listNums.Sum().ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listNums.Sort();
            MessageBox.Show(listNums[0].ToString());
            textBox9.Text =listNums[0].ToString();
            textBox10.Text = listNums[1].ToString();
            textBox11.Text = listNums[2].ToString();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox12.Text = "";
            foreach(int i in listNums)
            {
                textBox12.AppendText(i.ToString());
            }

        }
    }
}
