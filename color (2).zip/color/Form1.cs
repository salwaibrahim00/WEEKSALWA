﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace color
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (Control x in this.Controls)
            {
                if (x is TextBox textBox)

                {
                    if (double.TryParse(textBox.Text, out double inches))
                    {
                        double meters = inches * 0.0254;
                        textBox.Text = meters.ToString();

                        if (meters > 100)
                        {
                            textBox1.BackColor = color.blue;


                        }




                    }
                }
            }
        }
    }
}
