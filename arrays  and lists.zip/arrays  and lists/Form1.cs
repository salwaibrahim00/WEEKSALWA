﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp14
{
    public partial class Form1 : Form
    {
        decimal sum = 0;
        decimal[] nums = new decimal[4];
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (decimal.TryParse(textBox1.Text, out nums[0]) &&
               decimal.TryParse(textBox2.Text, out nums[1])&&
               decimal.TryParse(textBox5.Text, out nums[2])&&
              decimal.TryParse(textBox6.Text,out nums [3]))
             


            for (int i = 0; i < nums.Length; i++)
            {
                
                {
                    sum += nums[i];
                }
            }

                decimal average = sum / nums.Length;
                textBox8.Text = sum.ToString();
                    textBox9.Text = average.ToString("F2");
            }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
    }

